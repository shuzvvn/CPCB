please run in the order:
hw1.imputation.1.py
hw1.report.1.py
hw1.report.2.py
hw1.plot.1.py